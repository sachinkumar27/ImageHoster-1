﻿Project Details:


Using concepts such as Spring MVC, PostgreSQL and unit testing.

framework

Java
HTML
JPA
PostgreSQL
GIT 

Installation:

Please download the PostgreSQL To run the project


